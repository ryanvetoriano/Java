package br.com.fiap.beans;

public class Cliente {

    private String cpf;
    private String nome;
    private int idade;
    private Endereco endereco;

    //metodo construtor
    public Cliente(String cpf, String nome, int idade) {
        this.cpf = cpf;
        this.nome = nome;
        this.idade = idade;
    }

    //metodo construtor com parametro vazio
    public Cliente() {

    }


    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "\n\nCliente" +
                "\nCpf = " + cpf + '\'' +
                "\nNome = " + nome + '\'' +
                "\nIdade = " + idade +
                "\n\nEndereco = " + endereco;
    }
}
