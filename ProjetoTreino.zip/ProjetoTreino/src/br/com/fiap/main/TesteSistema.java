package br.com.fiap.main;

import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Endereco;
import br.com.fiap.beans.Produto;

import javax.swing.*;

public class TesteSistema {

    static String texto (String s){
        return JOptionPane.showInputDialog(s);
    }

    static int numero (String i){
        return Integer.parseInt(JOptionPane.showInputDialog(i));
    }

    static double decimal (String d){
        return Double.parseDouble(JOptionPane.showInputDialog(d));
    }

    public static void main(String[] args) {

        Cliente objCliente = new Cliente(
                texto("Cpf"),
                texto("Nome"),
                numero("Idade")
        );

        Produto objProduto = new Produto(
                numero("Código do produto"),
                texto("Tipo de Produto"),
                texto("Marca"),
                numero("Quantidade"),
                decimal("Valor")
        );

        Endereco objEndereco = new Endereco(
                texto("Rua"),
                numero("Número"),
                texto("Cep"),
                texto("Bairro"),
                texto("Cidade")
        );

        objCliente.setEndereco(objEndereco);

        System.out.println(objProduto +""+ objCliente);


    }


}
